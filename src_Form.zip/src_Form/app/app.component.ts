import { Component } from '@angular/core';
import { FormBuilder, FormControl,FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent 
{
  title = 'assignment_form';

  constructor(public fbobj : FormBuilder)
  {
  }

  Infoform = this.fbobj.group(
    {
     
      firstname :['', [Validators.required, Validators.pattern("[A-Za-z]+"),Validators.maxLength(20)] ],
      lastname :['', [Validators.required, Validators.pattern("[A-Za-z]+"),Validators.maxLength(20)] ],
      email:['', [Validators.required, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]],
      Phone:['',[Validators.required, Validators.pattern("^[0-9]*$"),Validators.minLength(10), Validators.maxLength(10)]],
    })


  

 
}
