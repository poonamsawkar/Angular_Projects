import { CustomstyleDirective } from './customstyle.directive';

describe('CustomstyleDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomstyleDirective();
    expect(directive).toBeTruthy();
  });
});
