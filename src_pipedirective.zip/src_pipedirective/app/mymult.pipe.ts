import { Pipe, PipeTransform } from '@angular/core';
var mult:any;
@Pipe({
  name: 'mymult'
})
export class MymultPipe implements PipeTransform {

  transform(value: number, Param:number): number 
  {
     mult=value*Param;
     return mult;
    
  }

}
