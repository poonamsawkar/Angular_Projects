import { Pipe, PipeTransform } from '@angular/core';

var num:number;
@Pipe({
  name: 'marvellousChk'
})
export class MarvellousChkPipe implements PipeTransform 
{

  transform(num: number, Param:string) : any
  {
    if(Param=='Even')
    {
      if(num%2==0)
      {
        return '11 is even number'
      }
      else 
      {
        return '11 is not even number';
      }
     
    }

    if(Param=='Odd')
    {
      if(num%2==1)
      {
        return '11 is odd number'
      }
      
      else 
      {
        console.log("Is not Odd Number",+num);
        return num;
      }
    }

    if(Param=='Prime')
    {
      var flag=true;
      for(let i = 2; i <= num - 1; i++)
      {
                if (num % i == 0) 
                {
                    flag = false;
                    break;
                }
                if (flag == true)
                return '11 is a prime number';
            else
            return '11 is not a prime number';
      }
    }

    if(Param='Perfect')
    {
      var sum=1;
      for (let i=2; i*i<=num; i++)
     {
        if (num%i==0)
        {
            if(i*i!=num)
                sum = sum + i + num/i;
            else
                sum=sum+i;
        }
        if (sum == num && num != 1)
        return '11 is perfect number'
        else 
        return '11 is not perfect number';    
     } 
    }

  }  
} 

 
    
  


