import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'pipedirective';
  public Name='Marvellous';
  public num:number= 11;
  public Param='';
}
