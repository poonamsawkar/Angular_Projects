import { Pipe, PipeTransform } from '@angular/core';

var Name='';

@Pipe({
  name: 'myrev'
})
export class MyrevPipe implements PipeTransform {

  transform(value:string): string 
  {
    
    for (var i = value.length - 1; i >= 0; i--) {
      Name += value.charAt(i);
      }
      return Name;
  }

}
