import { Directive } from '@angular/core';
import {ElementRef, HostListener} from '@angular/core';
@Directive({
  selector: '[appCompfailure]'
})
export class CompfailureDirective {

  constructor(private ele:ElementRef) 
  { }
  @HostListener('mouseenter') onmouseenter()
  {
    this.ele.nativeElement.style.color='red';
  }
  @HostListener('mouseleave') onmouseleave()
  {
    this.ele.nativeElement.style.color='black';
  }
}
