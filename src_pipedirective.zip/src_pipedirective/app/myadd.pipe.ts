import { Pipe, PipeTransform } from '@angular/core';
var add:any;
@Pipe({
  name: 'myadd'
})
export class MyaddPipe implements PipeTransform {

  transform(value: number, Param:number): number 
  {
     add=value+Param;
     return add;
    
  }

}
