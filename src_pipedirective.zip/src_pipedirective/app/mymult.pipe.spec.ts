import { MymultPipe } from './mymult.pipe';

describe('MymultPipe', () => {
  it('create an instance', () => {
    const pipe = new MymultPipe();
    expect(pipe).toBeTruthy();
  });
});
