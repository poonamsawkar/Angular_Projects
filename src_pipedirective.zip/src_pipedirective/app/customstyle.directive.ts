import { style } from '@angular/animations';
import { Directive } from '@angular/core';
import {ElementRef} from '@angular/core';
@Directive({
  selector: '[appCustomstyle]'
})
export class CustomstyleDirective {

  constructor(private ele:ElementRef) 
  {
    this.ele.nativeElement.style.background='yellow';
    

  }


}
