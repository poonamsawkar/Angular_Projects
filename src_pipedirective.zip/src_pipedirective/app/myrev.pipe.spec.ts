import { MyrevPipe } from './myrev.pipe';

describe('MyrevPipe', () => {
  it('create an instance', () => {
    const pipe = new MyrevPipe();
    expect(pipe).toBeTruthy();
  });
});
