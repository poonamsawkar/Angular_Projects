export interface IBatches
{
    Name:String,
    Duration:number,
    Fees:number
}